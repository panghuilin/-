package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import models.Admin;

public class Query {
	public static void main(String[] args) { 
		Configuration conf = new Configuration().configure();//读取Hibernate配置文件
		SessionFactory sf = conf.buildSessionFactory();//使用SessionFactory创建Session
		Session session = sf.openSession();
		Admin book = (Admin)session.get(Admin.class, "1");
		String bookid = book.getAdminId();
		String bookname = book.getAdminName();
		String bookprice = book.getAdminPs();
		System.out.println("ID:" + bookid);
		System.out.println("名字:" + bookname);
		System.out.println("用户:" + bookprice);
		//关闭session
		session.close();
	}
}
